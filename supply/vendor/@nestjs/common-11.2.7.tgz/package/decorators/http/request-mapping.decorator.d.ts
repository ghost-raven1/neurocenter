import { RequestMethod } from '../../enums/request-method.enum';
export interface RequestMappingMetadata {
    path?: string | string[];
    method?: RequestMethod;
}
export declare const RequestMapping: (metadata?: RequestMappingMetadata) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP POST requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Post: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP GET requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Get: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP DELETE requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Delete: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP PUT requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Put: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP PATCH requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Patch: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP OPTIONS requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Options: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP HEAD requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Head: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes all HTTP requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const All: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP SEARCH requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Search: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes HTTP QUERY requests to the specified path.
 *
 * **Note**: this is named `QueryMethod` (rather than `Query`) to avoid a name clash
 * with the `@Query()` parameter decorator used to extract query-string params.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const QueryMethod: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav PROPFIND requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Propfind: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav PROPPATCH requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Proppatch: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav MKCOL requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Mkcol: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav COPY requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Copy: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav MOVE requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Move: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav LOCK requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Lock: (path?: string | string[]) => MethodDecorator;
/**
 * Route handler (method) Decorator. Routes Webdav UNLOCK requests to the specified path.
 *
 * @see [Routing](https://docs.nestjs.com/controllers#routing)
 *
 * @publicApi
 */
export declare const Unlock: (path?: string | string[]) => MethodDecorator;
