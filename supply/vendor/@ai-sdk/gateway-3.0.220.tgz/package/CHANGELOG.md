# @ai-sdk/gateway

## 3.0.220

### Patch Changes

- fa49238: Add Voxtral 3 speech model IDs and support speech expressiveness and pronunciation hints in the Mistral provider.
- d301a16: Backport: chore(provider/gateway): update gateway model settings files
- 965effe: Backport: chore(provider/gateway): update gateway model settings files
- 4f82ab0: fix(provider/gateway): update `parallelSearch` for Parallel's GA Search API

  - Accept the `turbo`, `fast`, `basic`, and `advanced` modes. Tool calls that use one of these modes no longer fail client-side input validation. `one-shot` and `agentic` are deprecated but still accepted.
  - Add the `location` and top-level `maxCharsTotal` options, plus `fetchPolicy.timeoutSeconds` and `fetchPolicy.disableCacheFallback`. `excerpts.maxCharsTotal` is deprecated in favor of `maxCharsTotal`.
  - Fix the result type and schema to match the response the gateway returns: `search_id`, results with `url`, nullable `title` and `publish_date`, and `excerpts: string[]`, plus optional `warnings`, `usage`, and `session_id`. The `searchId`, `excerpt`, `publishDate`, and `relevanceScore` fields were never populated and are removed; update code that reads them. `validateUIMessages` now accepts Parallel Search results.

## 3.0.219

### Patch Changes

- ae8a8d4: Backport: chore(provider/gateway): update gateway model settings files
- 93e9720: Defer validation schema construction until first use to reduce provider import time.
- Updated dependencies [1183cc4]
- Updated dependencies [d726591]
  - @ai-sdk/provider-utils@4.0.62

## 3.0.218

### Patch Changes

- 37be196: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.217

### Patch Changes

- c42700c: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [5aa3086]
  - @ai-sdk/provider-utils@4.0.61

## 3.0.216

### Patch Changes

- Updated dependencies [739e9f6]
  - @ai-sdk/provider@3.0.19
  - @ai-sdk/provider-utils@4.0.60

## 3.0.215

### Patch Changes

- 0650c06: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [d5e7d82]
  - @ai-sdk/provider-utils@4.0.59

## 3.0.214

### Patch Changes

- d9244d1: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.213

### Patch Changes

- 0a2b345: feat(google): add `gemini-4-argon` model id and long decode support for `generateContent`: requests that reach the per-request cap (`CONTINUATION`) are continued automatically with usage summed across requests and the first request's prompt token count exposed as `providerMetadata.google.initialPromptTokenCount`, and the `continuationToken` provider option / provider metadata resume responses that used up their `maxOutputTokens` budget. `generateText` with the Interactions API now polls `background: true` model calls until they finish.
- 92ef6a5: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [604b4d3]
  - @ai-sdk/provider-utils@4.0.58

## 3.0.212

### Patch Changes

- 897cb0c: Backport: chore(provider/gateway): update gateway model settings files
- 7719e88: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.211

### Patch Changes

- bedd5bb: feat(anthropic): add Claude Haiku 5.5 support

  - add the `claude-haiku-5-5` model ID to `@ai-sdk/anthropic` and `@ai-sdk/google-vertex`, `anthropic.claude-haiku-5-5` and `us.anthropic.claude-haiku-5-5` to `@ai-sdk/amazon-bedrock`, and `anthropic/claude-haiku-5.5` to `@ai-sdk/gateway`
  - recognize `claude-haiku-5-5` as a known model with a 128k max output token limit and all five effort levels; thinking can be disabled up to `high` effort, and `xhigh` and `max` are lowered to `high` with a warning when thinking is disabled
  - `claude-haiku-5-5` does not support thinking token budgets: `thinking: { type: 'enabled', budgetTokens }` is converted to adaptive thinking with a warning
  - use the JSON tool fallback for structured output on Amazon Bedrock for `claude-haiku-5-5`

- 6dd6693: feat(google): add the 'gemini-nano-banana-2.1' model ID
- 5607cb2: Backport: chore(provider/gateway): update gateway model settings files
- fca8a28: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.210

### Patch Changes

- 3824c69: Backport: chore(provider/gateway): update gateway model settings files
- 6e8ec70: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.209

### Patch Changes

- 295aadf: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.208

### Patch Changes

- a2749a2: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.207

### Patch Changes

- Updated dependencies [a9cea74]
- Updated dependencies [a9cea74]
- Updated dependencies [a9cea74]
  - @ai-sdk/provider-utils@4.0.57

## 3.0.206

### Patch Changes

- 4972874: feat(openai): add GPT-6.1 Sol model support
- 03e5a25: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.205

### Patch Changes

- 358683e: feat(anthropic): add Claude Sonnet 5.5 support

  - add the `claude-sonnet-5-5` model ID to `@ai-sdk/anthropic` and `@ai-sdk/google-vertex`, `anthropic.claude-sonnet-5-5` and `us.anthropic.claude-sonnet-5-5` to `@ai-sdk/amazon-bedrock`, and `anthropic/claude-sonnet-5.5` to `@ai-sdk/gateway`
  - add the `between_tools` thinking type (`thinking: { type: 'between_tools' }`), the lowest thinking setting on `claude-sonnet-5-5`; `xhigh` and `max` effort are lowered to `high` with a warning because the API rejects them with `between_tools`
  - `claude-sonnet-5-5` rejects disabled thinking: `thinking: { type: 'disabled' }` is replaced with `between_tools` thinking (with a warning), and budget-based thinking is converted to adaptive thinking
  - `claude-sonnet-5-5` rejects forced tool use: `required` and named tool choices fall back to `auto`, and `structuredOutputMode: 'jsonTool'` falls back to native structured outputs, each with a warning

## 3.0.204

### Patch Changes

- Updated dependencies [29dc427]
  - @ai-sdk/provider-utils@4.0.56

## 3.0.203

### Patch Changes

- Updated dependencies [3983fea]
  - @ai-sdk/provider@3.0.18
  - @ai-sdk/provider-utils@4.0.55

## 3.0.202

### Patch Changes

- 2cf7cb4: feat (provider/gateway): add Browserbase Search and Fetch tool support
- af4a3e4: feat(provider/gateway): accept structured-output in the has provider option

## 3.0.201

### Patch Changes

- 1915a6f: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.200

### Patch Changes

- be4ca16: feat(provider/gateway): add quantization conditions to the has provider option
- ffb9507: Backport: chore(provider/gateway): update gateway model settings files
- bbd0115: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [069a945]
- Updated dependencies [d1a36d2]
- Updated dependencies [f7f36d2]
  - @ai-sdk/provider-utils@4.0.54

## 3.0.199

### Patch Changes

- 0b9d00b: feat: GPT-6 Sol and Luna model IDs
- Updated dependencies [da2e17b]
  - @ai-sdk/provider@3.0.17
  - @ai-sdk/provider-utils@4.0.53

## 3.0.198

### Patch Changes

- bd8bf1f: feat(anthropic): add Claude Opus 5.5 support

  - add the `claude-opus-5-5` model ID to `@ai-sdk/anthropic` and `anthropic/claude-opus-5.5` to `@ai-sdk/gateway`
  - models that always use adaptive thinking (`claude-opus-5-5`, `claude-fable-5`, `claude-fable-5-1`) no longer receive `thinking: { type: 'disabled' }` or budget-based thinking; the provider drops the unsupported setting and emits a warning
  - models that reject forced tool use (`claude-opus-5-5`, `claude-fable-5-1`) fall back to `auto` tool choice for `required` and named tool choices, and to native structured outputs when `structuredOutputMode: 'jsonTool'` is requested, each with a warning
  - add the `computerToolset_20260801` computer use tool (`computer_toolset_20260801`), which is required for computer use on `claude-opus-5-5`
  - use the documented `mid-conversation-output-config-2026-07-01` beta header for per-message effort

## 3.0.197

### Patch Changes

- 5f2d078: feat(provider/gateway): support `reasoning` and `tool-use` in `has` model filtering
- 1096a27: feat(xai): add grok 4.7 model ID
- 2a82d35: Backport: chore(provider/gateway): update gateway model settings files
- eea6869: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [82e18b0]
  - @ai-sdk/provider-utils@4.0.52

## 3.0.196

### Patch Changes

- 88d0bad: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.195

### Patch Changes

- 09e0817: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.194

### Patch Changes

- dc9fa12: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.193

### Patch Changes

- e4ff9e7: fix(gateway): forward server-returned warnings on language model doGenerate

  `generateText(...).warnings` through the gateway provider was always an empty
  array: `doGenerate` spread the gateway response body and then overwrote the
  server's `warnings` with a locally constructed empty array. The warnings the
  gateway relays from the upstream provider (and gateway-originated warnings)
  are now forwarded, matching the streaming path and every other modality.

## 3.0.192

### Patch Changes

- 1b7ff26: Backport: chore(provider/gateway): update gateway model settings files
- 4d228f2: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.191

### Patch Changes

- 1a4dbb1: Retry unclassified empty image results, preserve retry-attempt accounting, add provider-independent result retryability classification, preserve it through the AI Gateway, and mark Google and Google Vertex content-filtered results as terminal.
- b273f40: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [1a4dbb1]
  - @ai-sdk/provider@3.0.16
  - @ai-sdk/provider-utils@4.0.51

## 3.0.190

### Patch Changes

- fc032e8: Backport: chore(provider/gateway): update gateway model settings files
- 761dae9: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.189

### Patch Changes

- 8839d87: feat(gateway): add support for gpt-6-astra

## 3.0.188

### Patch Changes

- 13507cb: feat(google): add gemini-3.8-flash model
- 7782fec: Backport: chore(provider/gateway): update gateway model settings files
- 978e084: Backport: chore(provider/gateway): update gateway model settings files
- d0c255c: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.187

### Patch Changes

- 57d88f5: feat(anthropic): add fable 5.1 support

## 3.0.186

### Patch Changes

- 5ab6f63: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.185

### Patch Changes

- cc23556: Mark transient network errors that occur while reading successful response bodies as retryable.
- 823cc03: Backport: chore(provider/gateway): update gateway model settings files
- 3f96cf8: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [cc23556]
  - @ai-sdk/provider-utils@4.0.50

## 3.0.184

### Patch Changes

- 8ddf255: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [9a521b9]
  - @ai-sdk/provider-utils@4.0.49

## 3.0.183

### Patch Changes

- ad28ecb: Backport: Add GLM-5.3-Flash model support to the Z.AI provider and AI Gateway.

## 3.0.182

### Patch Changes

- 845ad6d: Remove the internal-only `relevance_score` and `citation_number` fields from
  published Tako Search response types and schemas. Code that reads either field
  must be updated; Gateway responses still pass the values through at runtime,
  but they are no longer typed. Also document data surcharge controls.
- fe80a3c: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.181

### Patch Changes

- Updated dependencies [5642849]
  - @ai-sdk/provider-utils@4.0.48

## 3.0.180

### Patch Changes

- f6efa51: Backport: chore(provider/gateway): update gateway model settings files
- 3539755: feat (provider/gateway): add Tako Search tool support
- Updated dependencies [2d172fb]
  - @ai-sdk/provider-utils@4.0.47

## 3.0.179

### Patch Changes

- 1e70580: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.178

### Patch Changes

- 7de3226: Backport: chore(provider/gateway): update gateway model settings files
- 504da15: feat: add DeepSeek V4 Flash Vision Exp image input support

## 3.0.177

### Patch Changes

- def7999: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.176

### Patch Changes

- 96304fc: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.175

### Patch Changes

- 000b243: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.174

### Patch Changes

- Updated dependencies [31205a4]
  - @ai-sdk/provider-utils@4.0.46

## 3.0.173

### Patch Changes

- 71e94ad: feat(google): add `gemini-3.7-flash` model

## 3.0.172

### Patch Changes

- 0ec239b: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.171

### Patch Changes

- 18b0965: Serialize structured Gateway error responses in nested API call error messages.
- 451d2c3: feat(xai): Add the Grok 4.6 model IDs and support its `xhigh` reasoning effort

## 3.0.170

### Patch Changes

- Updated dependencies [b2a4d5a]
  - @ai-sdk/provider-utils@4.0.45

## 3.0.169

### Patch Changes

- b39f987: Backport: chore(provider/gateway): update gateway model settings files
- d79117b: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.168

### Patch Changes

- Updated dependencies [2171d15]
  - @ai-sdk/provider@3.0.15
  - @ai-sdk/provider-utils@4.0.44

## 3.0.167

### Patch Changes

- Updated dependencies [dab0a08]
  - @ai-sdk/provider-utils@4.0.43

## 3.0.166

### Patch Changes

- Updated dependencies [ee2bf30]
  - @ai-sdk/provider-utils@4.0.42

## 3.0.165

### Patch Changes

- 0cd92fa: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.164

### Patch Changes

- f615718: Export `GatewayEmbeddingModelId` and `GatewayImageModelId` from the package entry point.
- 48d5dff: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.163

### Patch Changes

- 7e50c52: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.162

### Patch Changes

- b28367e: feat(provider/gateway): add `has` provider option for model capability filtering, supporting `'implicit-caching'` and `'vision'` (image input)

## 3.0.161

### Patch Changes

- d3d9e0b: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.160

### Patch Changes

- 87fb433: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [9ecdefe]
  - @ai-sdk/provider-utils@4.0.41

## 3.0.159

### Patch Changes

- de438f5: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.158

### Patch Changes

- 8418710: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.157

### Patch Changes

- 5d7b986: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.156

### Patch Changes

- e7d064f: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.155

### Patch Changes

- a09f944: feat(google): add `gemini-3.6-flash` and `gemini-3.5-flash-lite` models

## 3.0.154

### Patch Changes

- 2dd1aab: chore(provider/gateway): remove `hipaaCompliant` provider option
- e567091: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.153

### Patch Changes

- Updated dependencies [19093fd]
  - @ai-sdk/provider-utils@4.0.40

## 3.0.152

### Patch Changes

- 49a3098: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.151

### Patch Changes

- 5e624ac: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.150

### Patch Changes

- bc46977: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [06fb54c]
  - @ai-sdk/provider-utils@4.0.39

## 3.0.149

### Patch Changes

- 7c48ed8: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.148

### Patch Changes

- 982aa3e: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.147

### Patch Changes

- a452291: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.146

### Patch Changes

- 2bfb16a: feat(gateway): expose ruleId on GatewayForbiddenError so callers can identify which routing rule denied a request
- 34b5acc: feat(provider/openai,provider/gateway): add gpt-5.6 model ids
- 1ce0d1c: feat (provider/xai): add grok-4.5 model id
- Updated dependencies [e1af05f]
  - @ai-sdk/provider@3.0.14
  - @ai-sdk/provider-utils@4.0.38

## 3.0.145

### Patch Changes

- 9c54a9f: fix(gateway): accept deprecated warnings in image, speech, transcription, and video responses
- bbc4bd5: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [d559de9]
  - @ai-sdk/provider-utils@4.0.37

## 3.0.144

### Patch Changes

- 7dea716: feat(alibaba): support wan2.7 text-to-video and reference-to-video models with the new protocol (`input.media`, `resolution` + `ratio`)
- 4f7fe37: Backport: chore(provider/gateway): update gateway model settings files
- 0952964: Prevent prototype pollution when synchronously parsing provider JSON inputs and expose `secureJsonParse` from provider-utils.
- Updated dependencies [0952964]
  - @ai-sdk/provider-utils@4.0.36

## 3.0.143

### Patch Changes

- 8fbadac: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.142

### Patch Changes

- Updated dependencies [ea1e95b]
  - @ai-sdk/provider-utils@4.0.35

## 3.0.141

### Patch Changes

- 95bc6fd: feat (provider/anthropic): add `claude-sonnet-5` model id
- f6b2159: Backport: chore(provider/gateway): update gateway model settings files
- fa850e6: feat (video): add first-class `frameImages` and `inputReferences` call options for video generation
- Updated dependencies [fa850e6]
  - @ai-sdk/provider@3.0.13
  - @ai-sdk/provider-utils@4.0.34

## 3.0.140

### Patch Changes

- f6689df: feat(gateway): add `caching` provider option to `GatewayProviderOptions`
- 13b6a72: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.139

### Patch Changes

- Updated dependencies [b30e43a]
  - @ai-sdk/provider-utils@4.0.33

## 3.0.138

### Patch Changes

- fb601aa: feat (provider/gateway): add Exa search tool support
- f19334d: feat (video): add first-class `generateAudio` call option
- Updated dependencies [f19334d]
  - @ai-sdk/provider@3.0.12
  - @ai-sdk/provider-utils@4.0.32

## 3.0.137

### Patch Changes

- 932c680: Clarify `parallel_search` `source_policy` field descriptions so the model emits
  values the Parallel API accepts: `include_domains`/`exclude_domains` must be plain
  hosts (no scheme/path/port), and `after_date` must be an ISO 8601 calendar date
  formatted `YYYY-MM-DD`.

## 3.0.136

### Patch Changes

- 6ce12b0: Add Gateway speech and transcription model support.
- 4cb4414: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.135

### Patch Changes

- 1b40ac7: Publish all packages under the `@ai-v6` dist tag.
- Updated dependencies [1b40ac7]
  - @ai-sdk/provider-utils@4.0.31
  - @ai-sdk/provider@3.0.11

## 3.0.134

### Patch Changes

- 709c0fa: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.133

### Patch Changes

- 5bfde36: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [779f5cd]
  - @ai-sdk/provider-utils@4.0.30

## 3.0.132

### Patch Changes

- e962dda: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.131

### Patch Changes

- 6160ced: fix(gateway): surface provider warnings in embedding and reranking responses
- c9b8abd: fix(provider/gateway): map `forbidden` error responses to GatewayForbiddenError instead of GatewayInternalServerError

## 3.0.130

### Patch Changes

- c5d4716: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.129

### Patch Changes

- Updated dependencies [bfa5864]
- Updated dependencies [f42aa79]
  - @ai-sdk/provider-utils@4.0.29

## 3.0.128

### Patch Changes

- Updated dependencies [942f2f8]
  - @ai-sdk/provider-utils@4.0.28

## 3.0.127

### Patch Changes

- 3851e29: Backport: chore(provider/gateway): update gateway model settings files
- 2a91a17: feat(provider/anthropic): add support for `claude-fable-5` and the `fallbacks` API parameter

## 3.0.126

### Patch Changes

- ff16d3b: feat(gateway): add GatewayFailedDependencyError (424)

## 3.0.125

### Patch Changes

- fef3b24: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.124

### Patch Changes

- 286b7a2: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.123

### Patch Changes

- 537a022: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.122

### Patch Changes

- 9766034: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.121

### Patch Changes

- 4084fcd: feat(provider/anthropic): add support for `claude-opus-4-8`

## 3.0.120

### Patch Changes

- 27a1b22: Add `serviceTier: 'flex' | 'priority'` to `GatewayProviderOptions`.

## 3.0.119

### Patch Changes

- 33b10a2: Add `qwen3.7-max` model ID to Alibaba and AI Gateway.
- f6e4146: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.118

### Patch Changes

- 6f4bb06: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.117

### Patch Changes

- 756fec1: feat(provider/google): add `gemini-3.5-flash`

## 3.0.116

### Patch Changes

- 488ef33: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.115

### Patch Changes

- 363cefe: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.114

### Patch Changes

- 253bd5a: fix(gateway): enable retry support for gateway errors

## 3.0.113

### Patch Changes

- ee4de68: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.112

### Patch Changes

- 5c73af8: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.111

### Patch Changes

- Updated dependencies [f591416]
  - @ai-sdk/provider-utils@4.0.27

## 3.0.110

### Patch Changes

- 9a88b1d: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.109

### Patch Changes

- 49f6d44: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.108

### Patch Changes

- Updated dependencies [7beadf0]
  - @ai-sdk/provider-utils@4.0.26

## 3.0.107

### Patch Changes

- 982af78: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.106

### Patch Changes

- a727da4: chore: ensure consistent import handling and avoid import duplicates or cycles
- Updated dependencies [a727da4]
  - @ai-sdk/provider-utils@4.0.25
  - @ai-sdk/provider@3.0.10

## 3.0.105

### Patch Changes

- a7f3c72: trigger release for all packages after provenance setup
- 4368079: Backport: chore(provider/gateway): update gateway model settings files
- c71ad14: feat(provider/openai): add gpt-image-2 model support
- Updated dependencies [a7f3c72]
  - @ai-sdk/provider@3.0.9
  - @ai-sdk/provider-utils@4.0.24

## 3.0.104

### Patch Changes

- 493d7d4: bump `@vercel/oidc` dependency to 3.2.0

## 3.0.103

### Patch Changes

- 20805c8: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.102

### Patch Changes

- 2ff8d57: feat(provider/anthropic): add support for Opus 4.7 and relevant API enhancements

## 3.0.101

### Patch Changes

- 83434a9: feat (provider/gateway): add sort options

## 3.0.100

### Patch Changes

- a27a631: feat (provider/gateway): make model list resilient to unknown model types

## 3.0.99

### Patch Changes

- 8c4abaf: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.98

### Patch Changes

- 9031f26: fix (provider/gateway): add 'reranking' to modelType validation schema and type so getAvailableModels() accepts reranking models from the gateway API

## 3.0.97

### Patch Changes

- 06f7838: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.96

### Patch Changes

- a0d9373: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.95

### Patch Changes

- 08c5ac3: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.94

### Patch Changes

- 37a378e: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.93

### Patch Changes

- ec18852: feat (provider/gateway): add reranking model support with `rerankingModel()` and `reranking()` methods

## 3.0.92

### Patch Changes

- 9de7d7b: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.91

### Patch Changes

- 3aca847: feat (provider/gateway): add quotaEntityId gateway provider option

## 3.0.90

### Patch Changes

- e923a24: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.89

### Patch Changes

- Updated dependencies [6247886]
  - @ai-sdk/provider-utils@4.0.23

## 3.0.88

### Patch Changes

- 5f439a1: feat (provider/gateway): add hipaaCompliant gateway provider option

## 3.0.87

### Patch Changes

- ffd431a: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.86

### Patch Changes

- 15bfbd2: Backport: chore(provider/gateway): update gateway model settings files
- Updated dependencies [0469aed]
  - @ai-sdk/provider-utils@4.0.22

## 3.0.85

### Patch Changes

- 85e476d: feat (provider/gateway): add disallowPromptTraining gateway provider option

## 3.0.84

### Patch Changes

- 70322b4: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.83

### Patch Changes

- 768a9d6: feat (provider/gateway): add get-generation support

## 3.0.82

### Patch Changes

- 95fedf0: feat (provider/gateway): add spend reporting support

## 3.0.81

### Patch Changes

- e69062d: chore(provider/gateway): rename GatewayLanguageModelOptions back to GatewayProviderOptions

## 3.0.80

### Patch Changes

- 0db5cd8: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.79

### Patch Changes

- 3caa544: chore(provider/xai): update Grok 4.20 model IDs to their non-beta versions

## 3.0.78

### Patch Changes

- 763e178: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.77

### Patch Changes

- d99eb91: Backport: chore(provider/gateway): update gateway model settings files
- 055cd68: fix: publish v6 to latest npm dist tag
- Updated dependencies [055cd68]
  - @ai-sdk/provider-utils@4.0.21

## 3.0.76

### Patch Changes

- 25af909: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.75

### Patch Changes

- f95e0c0: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.74

### Patch Changes

- 7324b56: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.73

### Patch Changes

- ac0c407: Backport: chore(provider/gateway): update gateway model settings files
- e748159: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.72

### Patch Changes

- 5ffb1ad: feat(provider/google): add `gemini-embedding-2-preview` and fix multimodal embedding support with `embedMany`
- f5bf0c6: Backport: chore(provider/gateway): update gateway model settings files

## 3.0.71

### Patch Changes

- 55ccbe2: chore(provider/xai): remove obsolete Grok 2 models now that they are shut down in their API

## 3.0.70

### Patch Changes

- ca0b430: chore(provider/gateway): update gateway model settings files

## 3.0.69

### Patch Changes

- efdaefc: chore(provider/gateway): update gateway model settings files

## 3.0.68

### Patch Changes

- Updated dependencies [64ac0fd]
  - @ai-sdk/provider-utils@4.0.20

## 3.0.67

### Patch Changes

- 2589004: feat(provider/openai): add GPT-5.4 model support

## 3.0.66

### Patch Changes

- Updated dependencies [ad4cfc2]
  - @ai-sdk/provider-utils@4.0.19

## 3.0.65

### Patch Changes

- Updated dependencies [824b295]
  - @ai-sdk/provider-utils@4.0.18

## 3.0.64

### Patch Changes

- db3d4ca: chore(provider/gateway): update gateway model settings files

## 3.0.63

### Patch Changes

- 1b01ec1: feat(gateway): add providerTimeouts to provider options
- 8df8e11: chore(provider/gateway): update gateway model settings files

## 3.0.62

### Patch Changes

- 10bec50: feat(provider/google): add `gemini-3.1-flash-lite-preview`

## 3.0.61

### Patch Changes

- Updated dependencies [08336f1]
  - @ai-sdk/provider-utils@4.0.17

## 3.0.60

### Patch Changes

- 29e9f4d: chore(provider/gateway): update gateway model settings files

## 3.0.59

### Patch Changes

- Updated dependencies [58bc42d]
  - @ai-sdk/provider-utils@4.0.16

## 3.0.58

### Patch Changes

- 1330f2f: chore(provider/gateway): update gateway model settings files

## 3.0.57

### Patch Changes

- ba63bc2: chore(provider/gateway): update gateway model settings files

## 3.0.56

### Patch Changes

- 45f0a7f: feat(provider/google): add support for gemini-3.1-flash-image-preview

## 3.0.55

### Patch Changes

- e8172b6: feat (provider/gateway): pass through project id when available for o11y

## 3.0.54

### Patch Changes

- 0c9395b: feat(provider/openai): add `gpt-5.3-codex`

## 3.0.53

### Patch Changes

- 73b7e09: feat (provider/gateway): add SSE support for video generation with heartbeat keep-alive

## 3.0.52

### Patch Changes

- 363fa44: chore(provider/gateway): update gateway model settings files

## 3.0.51

### Patch Changes

- 765b013: feat(provider/google): add support for `gemini-3.1-pro-preview`

## 3.0.50

### Patch Changes

- a433cd3: chore(provider/gateway): update gateway model settings files

## 3.0.49

### Patch Changes

- 5f693c8: chore(provider/gateway): update gateway model settings files

## 3.0.48

### Patch Changes

- 2a1c664: feat(provider/anthropic): add support for new Claude Sonnet 4.6 model

## 3.0.47

### Patch Changes

- 6bbd05b: chore(provider/gateway): update gateway model settings files

## 3.0.46

### Patch Changes

- f75f18c: chore(provider/gateway): update gateway model settings files

## 3.0.45

### Patch Changes

- e858654: fix (provider/gateway): Fixed error handling in Gateway models by making asGatewayError async in both image and video model implementations.

## 3.0.44

### Patch Changes

- Updated dependencies [4024a3a]
  - @ai-sdk/provider-utils@4.0.15

## 3.0.43

### Patch Changes

- b424e50: chore(provider/gateway): update gateway model settings files

## 3.0.42

### Patch Changes

- 1819bc1: fix (provider/gateway): add missing warning types for video response parsing

## 3.0.41

### Patch Changes

- 99fbed8: feat: normalize provider specific model options type names and ensure they are exported

## 3.0.40

### Patch Changes

- a2208a2: fix (provider/gateway): added custom error class and message for client side timeouts

## 3.0.39

### Patch Changes

- eea5d30: fix: image generation via Gateway warning schema mismatch

## 3.0.38

### Patch Changes

- 70028ab: feat: report image generation usage info in Gateway

## 3.0.37

### Patch Changes

- Updated dependencies [7168375]
  - @ai-sdk/provider@3.0.8
  - @ai-sdk/provider-utils@4.0.14

## 3.0.36

### Patch Changes

- 9892c58: feat(anthropic): add support for Opus 4.6

## 3.0.35

### Patch Changes

- 8e2eaac: chore(provider/gateway): update gateway model settings files

## 3.0.34

### Patch Changes

- 4867635: feat (provider/gateway): add video generation support

## 3.0.33

### Patch Changes

- ae30443: fix(google): remove shut down `gemini-2.5-flash-image-preview`

## 3.0.32

### Patch Changes

- Updated dependencies [53f6731]
  - @ai-sdk/provider@3.0.7
  - @ai-sdk/provider-utils@4.0.13

## 3.0.31

### Patch Changes

- Updated dependencies [96936e5]
  - @ai-sdk/provider-utils@4.0.12

## 3.0.30

### Patch Changes

- 1a74972: chore(provider/gateway): update gateway model settings files

## 3.0.29

### Patch Changes

- Updated dependencies [2810850]
  - @ai-sdk/provider-utils@4.0.11
  - @ai-sdk/provider@3.0.6

## 3.0.28

### Patch Changes

- 1524271: chore: add skill information to README files

## 3.0.27

### Patch Changes

- 0acff64: feat (provider/gateway): add parallel search tool

## 3.0.26

### Patch Changes

- a8be296: chore(provider/gateway): update gateway model settings files

## 3.0.25

### Patch Changes

- 15a78c7: chore(provider/gateway): update gateway model settings files

## 3.0.24

### Patch Changes

- Updated dependencies [462ad00]
  - @ai-sdk/provider-utils@4.0.10

## 3.0.23

### Patch Changes

- cbf1704: chore(provider/gateway): update gateway model settings files

## 3.0.22

### Patch Changes

- 4de5a1d: chore: excluded tests from src folder in npm package
- Updated dependencies [4de5a1d]
  - @ai-sdk/provider@3.0.5
  - @ai-sdk/provider-utils@4.0.9

## 3.0.21

### Patch Changes

- 2b8369d: chore: add docs to package dist

## 3.0.20

### Patch Changes

- 8dc54db: chore: add src folders to package bundle

## 3.0.19

### Patch Changes

- c60fdd8: Inline fullMessage variable in GatewayError constructor

## 3.0.18

### Patch Changes

- 7af4eb4: chore(provider/gateway): update gateway model settings files

## 3.0.17

### Patch Changes

- 66d78d5: chore(provider/gateway): update gateway model settings files

## 3.0.16

### Patch Changes

- Updated dependencies [5c090e7]
  - @ai-sdk/provider@3.0.4
  - @ai-sdk/provider-utils@4.0.8

## 3.0.15

### Patch Changes

- Updated dependencies [46f46e4]
  - @ai-sdk/provider-utils@4.0.7

## 3.0.14

### Patch Changes

- Updated dependencies [1b11dcb]
  - @ai-sdk/provider-utils@4.0.6
  - @ai-sdk/provider@3.0.3

## 3.0.13

### Patch Changes

- 92b339b: feat (provider/gateway): add'l perplexity search tool params

## 3.0.12

### Patch Changes

- Updated dependencies [34d1c8a]
  - @ai-sdk/provider-utils@4.0.5

## 3.0.11

### Patch Changes

- 891a60a: feat (provider/gateway): add provider-defined perplexity search

## 3.0.10

### Patch Changes

- 2696fd2: chore(provider/gateway): Update gateway model settings files

## 3.0.9

### Patch Changes

- Updated dependencies [d937c8f]
  - @ai-sdk/provider@3.0.2
  - @ai-sdk/provider-utils@4.0.4

## 3.0.8

### Patch Changes

- 8ec1984: fix(gateway): bump `@vercel/oidc` to 3.1.0

## 3.0.7

### Patch Changes

- Updated dependencies [0b429d4]
  - @ai-sdk/provider-utils@4.0.3

## 3.0.6

### Patch Changes

- 74c0157: feat (provider/gateway): support image editing

## 3.0.5

### Patch Changes

- 7ee2d12: chore (provider/gateway): bump specification version header to reflect v3

## 3.0.4

### Patch Changes

- 863d34f: fix: trigger release to update `@latest`
- Updated dependencies [863d34f]
  - @ai-sdk/provider@3.0.1
  - @ai-sdk/provider-utils@4.0.2

## 3.0.3

### Patch Changes

- 1dad057: fix(gateway): add error handling for oidc refresh

## 3.0.2

### Patch Changes

- Updated dependencies [29264a3]
  - @ai-sdk/provider-utils@4.0.1

## 3.0.1

### Patch Changes

- c0c8a0e: Add zai/glm-4.7 model support

## 3.0.0

### Major Changes

- 387980f: fix: major version bump for AI SDK v6

## 2.0.0

### Major Changes

- dee8b05: ai SDK 6 beta
- 2f8b0c8: fix(gateway): bump `@vercel/oidc` to latest

### Minor Changes

- 78928cb: release: start 5.1 beta

### Patch Changes

- 0c3b58b: fix(provider): add specificationVersion to ProviderV3
- ea9ca31: feat(provider/gateway): Add new xAI models
- 5dd4c6a: fix(provider/gateway): Fix Gateway image model provider options not passing through
- 5d21222: feat(provider/gateway): Add gpt-5-codex to Gateway model string autocomplete
- 0adc679: feat(provider): shared spec v3
- 7294355: feat (provider/gateway): update route path version and embed format
- e8694af: feat(provider/gateway): Server-side image request splitting
- 8d9e8ad: chore(provider): remove generics from EmbeddingModelV3

  Before

  ```ts
  model.textEmbeddingModel("my-model-id");
  ```

  After

  ```ts
  model.embeddingModel("my-model-id");
  ```

- aaf5ebf: feat(provider/gateway): Add new Qwen models to Gateway model string autocomplete
- 95f65c2: chore: use import \* from zod/v4
- c823faf: feat(provider/gateway): Add new Gemini preview models to Gateway model string autocomplete
- 2b6a848: feat (provider/gateway): add models provider option for model routing
- 0c4822d: feat: `EmbeddingModelV3`
- 34ee8d0: feat (provider/gateway): add support for request-scoped byok
- 1890317: feat (provider/gateway): improve auth error messages
- 636e614: feat(provider/gateway): Add DeepSeek V3.2 Exp to Gateway language model settings
- 7ccb36f: feat(provider/gateway): Add LongCat Thinking model to Gateway autocomplete
- ed329cb: feat: `Provider-V3`
- 5f66123: chore(provider/gateway): Update gateway language model settings
- 1cad0ab: feat: add provider version to user-agent header
- bca7e61: feat(provider/gateway): Change default maxImagesPerCall per-provider
- 8dac895: feat: `LanguageModelV3`
- 3e83633: add getCredits() gateway method
- 1d8ea2c: feat(provider/gateway): Add GPT-5 pro to Gateway model string autocomplete
- ef62178: feat(gateway): oidc refresh with `@vercel/oidc`
- 0a2ff8a: feat (provider/gateway): add user and tags provider options
- ee71658: feat (provider/gateway): add zero data retention provider option
- 457318b: chore(provider,ai): switch to SharedV3Warning and unified warnings
- 9061dc0: feat: image editing
- 7d73922: feat(provider/gateway): Add MiniMax M2 to Gateway autocomplete
- e6bfe91: feat(provider/gateway): Update DeepSeek model string autocomplete
- acc14d8: feat (provider/gateway): add 'only' to provider options
- f83903d: getCredits style improvements
- 0e29b8b: chore(provider/gateway): lazy schema loading
- 366f50b: chore(provider): add deprecated textEmbeddingModel and textEmbedding aliases
- cdd0bc2: feat (provider/gateway): add intellect-3 model id
- 96322b7: feat(provider/gateway): Add GPT OSS Safeguard 20B to Gateway model string autocomplete
- 4616b86: chore: update zod peer depenedency version
- 2d166e4: feat(provider/gateway): add support for image models
- 6c766ef: feat(provider/gateway): Add DeepSeek V3.1 Terminus to Gateway autocomplete
- 7b1b1b1: fix(provider/gateway): add "react-native" as export condition for browser behavior

  This avoids the use of native Node APIs in bundles created for React Native / Expo apps

- 3782645: bump `@vercel/oidc` to 3.0.5
- f18ef7f: feat(openai): add gpt-5.2 models
- 1425df5: feat(provider/gateway): Add Imagen 4 Ultra Generate to model string autocomplete list
- 9f6149e: feat(provider/gateway): Add Sonnet 4.5 to Gateway model string autocomplete
- cc5170d: feat(provider/gateway): update gateway model string autocomplete
- a90dca6: feat(provider/gateway): Add zAI GLM 4.6 to Gateway language model settings
- b1624f0: feat (provider/gateway): add trinity-mini model id
- cbf52cd: feat: expose raw finish reason
- 870297d: feat(google): gemini-3-flash
- f0b2157: fix: revert zod import change
- Updated dependencies
  - @ai-sdk/provider@3.0.0
  - @ai-sdk/provider-utils@4.0.0

## 2.0.0-beta.93

### Patch Changes

- 7294355: feat (provider/gateway): update route path version and embed format

## 2.0.0-beta.92

### Patch Changes

- Updated dependencies [475189e]
  - @ai-sdk/provider@3.0.0-beta.32
  - @ai-sdk/provider-utils@4.0.0-beta.59

## 2.0.0-beta.91

### Patch Changes

- Updated dependencies [2625a04]
  - @ai-sdk/provider@3.0.0-beta.31
  - @ai-sdk/provider-utils@4.0.0-beta.58

## 2.0.0-beta.90

### Patch Changes

- cbf52cd: feat: expose raw finish reason
- Updated dependencies [cbf52cd]
  - @ai-sdk/provider@3.0.0-beta.30
  - @ai-sdk/provider-utils@4.0.0-beta.57

## 2.0.0-beta.89

### Patch Changes

- Updated dependencies [9549c9e]
  - @ai-sdk/provider@3.0.0-beta.29
  - @ai-sdk/provider-utils@4.0.0-beta.56

## 2.0.0-beta.88

### Patch Changes

- Updated dependencies [50b70d6]
  - @ai-sdk/provider-utils@4.0.0-beta.55

## 2.0.0-beta.87

### Patch Changes

- ee71658: feat (provider/gateway): add zero data retention provider option

## 2.0.0-beta.86

### Patch Changes

- 9061dc0: feat: image editing
- Updated dependencies [9061dc0]
  - @ai-sdk/provider-utils@4.0.0-beta.54
  - @ai-sdk/provider@3.0.0-beta.28

## 2.0.0-beta.85

### Patch Changes

- 870297d: feat(google): gemini-3-flash

## 2.0.0-beta.84

### Patch Changes

- 366f50b: chore(provider): add deprecated textEmbeddingModel and textEmbedding aliases
- Updated dependencies [366f50b]
  - @ai-sdk/provider@3.0.0-beta.27
  - @ai-sdk/provider-utils@4.0.0-beta.53

## 2.0.0-beta.83

### Patch Changes

- Updated dependencies [763d04a]
  - @ai-sdk/provider-utils@4.0.0-beta.52

## 2.0.0-beta.82

### Patch Changes

- Updated dependencies [c1efac4]
  - @ai-sdk/provider-utils@4.0.0-beta.51

## 2.0.0-beta.81

### Patch Changes

- Updated dependencies [32223c8]
  - @ai-sdk/provider-utils@4.0.0-beta.50

## 2.0.0-beta.80

### Patch Changes

- Updated dependencies [83e5744]
  - @ai-sdk/provider-utils@4.0.0-beta.49

## 2.0.0-beta.79

### Patch Changes

- Updated dependencies [960ec8f]
  - @ai-sdk/provider-utils@4.0.0-beta.48

## 2.0.0-beta.78

### Patch Changes

- f18ef7f: feat(openai): add gpt-5.2 models

## 2.0.0-beta.77

### Patch Changes

- Updated dependencies [e9e157f]
  - @ai-sdk/provider-utils@4.0.0-beta.47

## 2.0.0-beta.76

### Patch Changes

- 34ee8d0: feat (provider/gateway): add support for request-scoped byok

## 2.0.0-beta.75

### Patch Changes

- Updated dependencies [81e29ab]
  - @ai-sdk/provider-utils@4.0.0-beta.46

## 2.0.0-beta.74

### Patch Changes

- Updated dependencies [3bd2689]
  - @ai-sdk/provider@3.0.0-beta.26
  - @ai-sdk/provider-utils@4.0.0-beta.45

## 2.0.0-beta.73

### Patch Changes

- Updated dependencies [53f3368]
  - @ai-sdk/provider@3.0.0-beta.25
  - @ai-sdk/provider-utils@4.0.0-beta.44

## 2.0.0-beta.72

### Patch Changes

- Updated dependencies [dce03c4]
  - @ai-sdk/provider-utils@4.0.0-beta.43
  - @ai-sdk/provider@3.0.0-beta.24

## 2.0.0-beta.71

### Patch Changes

- Updated dependencies [3ed5519]
  - @ai-sdk/provider-utils@4.0.0-beta.42

## 2.0.0-beta.70

### Patch Changes

- Updated dependencies [1bd7d32]
  - @ai-sdk/provider-utils@4.0.0-beta.41
  - @ai-sdk/provider@3.0.0-beta.23

## 2.0.0-beta.69

### Patch Changes

- b1624f0: feat (provider/gateway): add trinity-mini model id

## 2.0.0-beta.68

### Patch Changes

- Updated dependencies [544d4e8]
  - @ai-sdk/provider-utils@4.0.0-beta.40
  - @ai-sdk/provider@3.0.0-beta.22

## 2.0.0-beta.67

### Patch Changes

- Updated dependencies [954c356]
  - @ai-sdk/provider-utils@4.0.0-beta.39
  - @ai-sdk/provider@3.0.0-beta.21

## 2.0.0-beta.66

### Patch Changes

- Updated dependencies [03849b0]
  - @ai-sdk/provider-utils@4.0.0-beta.38

## 2.0.0-beta.65

### Patch Changes

- cdd0bc2: feat (provider/gateway): add intellect-3 model id

## 2.0.0-beta.64

### Patch Changes

- 457318b: chore(provider,ai): switch to SharedV3Warning and unified warnings
- Updated dependencies [457318b]
  - @ai-sdk/provider@3.0.0-beta.20
  - @ai-sdk/provider-utils@4.0.0-beta.37

## 2.0.0-beta.63

### Patch Changes

- 8d9e8ad: chore(provider): remove generics from EmbeddingModelV3

  Before

  ```ts
  model.textEmbeddingModel("my-model-id");
  ```

  After

  ```ts
  model.embeddingModel("my-model-id");
  ```

- Updated dependencies [8d9e8ad]
  - @ai-sdk/provider@3.0.0-beta.19
  - @ai-sdk/provider-utils@4.0.0-beta.36

## 2.0.0-beta.62

### Patch Changes

- Updated dependencies [10d819b]
  - @ai-sdk/provider@3.0.0-beta.18
  - @ai-sdk/provider-utils@4.0.0-beta.35

## 2.0.0-beta.61

### Patch Changes

- e8694af: feat(provider/gateway): Server-side image request splitting

## 2.0.0-beta.60

### Patch Changes

- Updated dependencies [db913bd]
  - @ai-sdk/provider@3.0.0-beta.17
  - @ai-sdk/provider-utils@4.0.0-beta.34

## 2.0.0-beta.59

### Patch Changes

- 5dd4c6a: fix(provider/gateway): Fix Gateway image model provider options not passing through

## 2.0.0-beta.58

### Patch Changes

- 1425df5: feat(provider/gateway): Add Imagen 4 Ultra Generate to model string autocomplete list

## 2.0.0-beta.57

### Patch Changes

- bca7e61: feat(provider/gateway): Change default maxImagesPerCall per-provider

## 2.0.0-beta.56

### Patch Changes

- 2d166e4: feat(provider/gateway): add support for image models

## 2.0.0-beta.55

### Patch Changes

- cc5170d: feat(provider/gateway): update gateway model string autocomplete

## 2.0.0-beta.54

### Patch Changes

- 5f66123: chore(provider/gateway): Update gateway language model settings

## 2.0.0-beta.53

### Patch Changes

- 3782645: bump `@vercel/oidc` to 3.0.5

## 2.0.0-beta.52

### Patch Changes

- Updated dependencies [b681d7d]
  - @ai-sdk/provider@3.0.0-beta.16
  - @ai-sdk/provider-utils@4.0.0-beta.33

## 2.0.0-beta.51

### Patch Changes

- Updated dependencies [32d8dbb]
  - @ai-sdk/provider-utils@4.0.0-beta.32

## 2.0.0-beta.50

### Patch Changes

- Updated dependencies [bb36798]
  - @ai-sdk/provider@3.0.0-beta.15
  - @ai-sdk/provider-utils@4.0.0-beta.31

## 2.0.0-beta.49

### Patch Changes

- Updated dependencies [4f16c37]
  - @ai-sdk/provider-utils@4.0.0-beta.30

## 2.0.0-beta.48

### Patch Changes

- Updated dependencies [af3780b]
  - @ai-sdk/provider@3.0.0-beta.14
  - @ai-sdk/provider-utils@4.0.0-beta.29

## 2.0.0-beta.47

### Patch Changes

- 96322b7: feat(provider/gateway): Add GPT OSS Safeguard 20B to Gateway model string autocomplete

## 2.0.0-beta.46

### Patch Changes

- Updated dependencies [016b111]
  - @ai-sdk/provider-utils@4.0.0-beta.28

## 2.0.0-beta.45

### Patch Changes

- Updated dependencies [37c58a0]
  - @ai-sdk/provider@3.0.0-beta.13
  - @ai-sdk/provider-utils@4.0.0-beta.27

## 2.0.0-beta.44

### Patch Changes

- 7d73922: feat(provider/gateway): Add MiniMax M2 to Gateway autocomplete

## 2.0.0-beta.43

### Patch Changes

- Updated dependencies [d1bdadb]
  - @ai-sdk/provider@3.0.0-beta.12
  - @ai-sdk/provider-utils@4.0.0-beta.26

## 2.0.0-beta.42

### Patch Changes

- Updated dependencies [4c44a5b]
  - @ai-sdk/provider@3.0.0-beta.11
  - @ai-sdk/provider-utils@4.0.0-beta.25

## 2.0.0-beta.41

### Patch Changes

- 0c3b58b: fix(provider): add specificationVersion to ProviderV3
- Updated dependencies [0c3b58b]
  - @ai-sdk/provider@3.0.0-beta.10
  - @ai-sdk/provider-utils@4.0.0-beta.24

## 2.0.0-beta.40

### Patch Changes

- Updated dependencies [a755db5]
  - @ai-sdk/provider@3.0.0-beta.9
  - @ai-sdk/provider-utils@4.0.0-beta.23

## 2.0.0-beta.39

### Patch Changes

- Updated dependencies [58920e0]
  - @ai-sdk/provider-utils@4.0.0-beta.22

## 2.0.0-beta.38

### Patch Changes

- Updated dependencies [293a6b7]
  - @ai-sdk/provider-utils@4.0.0-beta.21

## 2.0.0-beta.37

### Patch Changes

- 2b6a848: feat (provider/gateway): add models provider option for model routing

## 2.0.0-beta.36

### Patch Changes

- Updated dependencies [fca786b]
  - @ai-sdk/provider-utils@4.0.0-beta.20

## 2.0.0-beta.35

### Patch Changes

- Updated dependencies [3794514]
  - @ai-sdk/provider-utils@4.0.0-beta.19
  - @ai-sdk/provider@3.0.0-beta.8

## 2.0.0-beta.34

### Major Changes

- 2f8b0c8: fix(gateway): bump `@vercel/oidc` to latest

## 2.0.0-beta.33

### Patch Changes

- 1890317: feat (provider/gateway): improve auth error messages

## 2.0.0-beta.32

### Patch Changes

- Updated dependencies [81d4308]
  - @ai-sdk/provider@3.0.0-beta.7
  - @ai-sdk/provider-utils@4.0.0-beta.18

## 2.0.0-beta.31

### Patch Changes

- Updated dependencies [703459a]
  - @ai-sdk/provider-utils@4.0.0-beta.17

## 2.0.0-beta.30

### Patch Changes

- 0a2ff8a: feat (provider/gateway): add user and tags provider options

## 2.0.0-beta.29

### Patch Changes

- Updated dependencies [6306603]
  - @ai-sdk/provider-utils@4.0.0-beta.16

## 2.0.0-beta.28

### Patch Changes

- f0b2157: fix: revert zod import change
- Updated dependencies [f0b2157]
  - @ai-sdk/provider-utils@4.0.0-beta.15

## 2.0.0-beta.27

### Patch Changes

- Updated dependencies [3b1d015]
  - @ai-sdk/provider-utils@4.0.0-beta.14

## 2.0.0-beta.26

### Patch Changes

- Updated dependencies [d116b4b]
  - @ai-sdk/provider-utils@4.0.0-beta.13

## 2.0.0-beta.25

### Patch Changes

- Updated dependencies [7e32fea]
  - @ai-sdk/provider-utils@4.0.0-beta.12

## 2.0.0-beta.24

### Patch Changes

- 0e29b8b: chore(provider/gateway): lazy schema loading

## 2.0.0-beta.23

### Patch Changes

- acc14d8: feat (provider/gateway): add 'only' to provider options

## 2.0.0-beta.22

### Patch Changes

- 95f65c2: chore: use import \* from zod/v4
- Updated dependencies
  - @ai-sdk/provider-utils@4.0.0-beta.11

## 2.0.0-beta.21

### Patch Changes

- 7b1b1b1: fix(provider/gateway): add "react-native" as export condition for browser behavior

  This avoids the use of native Node APIs in bundles created for React Native / Expo apps

## 2.0.0-beta.20

### Major Changes

- dee8b05: ai SDK 6 beta

### Patch Changes

- Updated dependencies [dee8b05]
  - @ai-sdk/provider@3.0.0-beta.6
  - @ai-sdk/provider-utils@4.0.0-beta.10

## 1.1.0-beta.19

### Patch Changes

- Updated dependencies [521c537]
  - @ai-sdk/provider-utils@3.1.0-beta.9

## 1.1.0-beta.18

### Patch Changes

- Updated dependencies [e06565c]
  - @ai-sdk/provider-utils@3.1.0-beta.8

## 1.1.0-beta.17

### Patch Changes

- 1d8ea2c: feat(provider/gateway): Add GPT-5 pro to Gateway model string autocomplete

## 1.1.0-beta.16

### Patch Changes

- Updated dependencies
  - @ai-sdk/provider@2.1.0-beta.5
  - @ai-sdk/provider-utils@3.1.0-beta.7

## 1.1.0-beta.15

### Patch Changes

- ef62178: feat(gateway): oidc refresh with `@vercel/oidc`

## 1.1.0-beta.14

### Patch Changes

- a90dca6: feat(provider/gateway): Add zAI GLM 4.6 to Gateway language model settings

## 1.1.0-beta.13

### Patch Changes

- 0adc679: feat(provider): shared spec v3
- Updated dependencies
  - @ai-sdk/provider-utils@3.1.0-beta.6
  - @ai-sdk/provider@2.1.0-beta.4

## 1.1.0-beta.12

### Patch Changes

- e6bfe91: feat(provider/gateway): Update DeepSeek model string autocomplete

## 1.1.0-beta.11

### Patch Changes

- 636e614: feat(provider/gateway): Add DeepSeek V3.2 Exp to Gateway language model settings

## 1.1.0-beta.10

### Patch Changes

- 9f6149e: feat(provider/gateway): Add Sonnet 4.5 to Gateway model string autocomplete

## 1.1.0-beta.9

### Patch Changes

- 8dac895: feat: `LanguageModelV3`
- Updated dependencies [8dac895]
  - @ai-sdk/provider-utils@3.1.0-beta.5
  - @ai-sdk/provider@2.1.0-beta.3

## 1.1.0-beta.8

### Patch Changes

- c823faf: feat(provider/gateway): Add new Gemini preview models to Gateway model string autocomplete

## 1.1.0-beta.7

### Patch Changes

- 4616b86: chore: update zod peer depenedency version
- Updated dependencies [4616b86]
  - @ai-sdk/provider-utils@3.1.0-beta.4

## 1.1.0-beta.6

### Patch Changes

- aaf5ebf: feat(provider/gateway): Add new Qwen models to Gateway model string autocomplete
- ed329cb: feat: `Provider-V3`
- Updated dependencies
  - @ai-sdk/provider@2.1.0-beta.2
  - @ai-sdk/provider-utils@3.1.0-beta.3

## 1.1.0-beta.5

### Patch Changes

- 5d21222: feat(provider/gateway): Add gpt-5-codex to Gateway model string autocomplete
- 0c4822d: feat: `EmbeddingModelV3`
- 1cad0ab: feat: add provider version to user-agent header
- Updated dependencies [0c4822d]
  - @ai-sdk/provider@2.1.0-beta.1
  - @ai-sdk/provider-utils@3.1.0-beta.2

## 1.1.0-beta.4

### Patch Changes

- 7ccb36f: feat(provider/gateway): Add LongCat Thinking model to Gateway autocomplete
- 6c766ef: feat(provider/gateway): Add DeepSeek V3.1 Terminus to Gateway autocomplete

## 1.1.0-beta.3

### Patch Changes

- ea9ca31: feat(provider/gateway): Add new xAI models

## 1.1.0-beta.2

### Patch Changes

- 3e83633: add getCredits() gateway method
- f83903d: getCredits style improvements

## 1.1.0-beta.1

### Patch Changes

- Updated dependencies [cbb1d35]
  - @ai-sdk/provider-utils@3.1.0-beta.1

## 1.1.0-beta.0

### Minor Changes

- 78928cb: release: start 5.1 beta

### Patch Changes

- Updated dependencies [78928cb]
  - @ai-sdk/provider@2.1.0-beta.0
  - @ai-sdk/provider-utils@3.1.0-beta.0

## 1.0.23

### Patch Changes

- f49f924: feat (provider/gateway): add qwen3 next model ids

## 1.0.22

### Patch Changes

- Updated dependencies [0294b58]
  - @ai-sdk/provider-utils@3.0.9

## 1.0.21

### Patch Changes

- 4ee3719: feat(provider/gateway): Add Meituan LongCat Flash Chat to autocomplete

## 1.0.20

### Patch Changes

- 350a328: feat(provider/gateway): Add stealth models to Gateway autocomplete

## 1.0.19

### Patch Changes

- 034287f: feat (provider/gateway): add qwen3-max model id
- dee1afe: feat(provider/gateway): Fix embeddings `providerOptions`

## 1.0.18

### Patch Changes

- 5d59a8c: feat (provider/gateway): add moonshotai/kimi-k2-0905 model id

## 1.0.17

### Patch Changes

- b6005cd: feat(provider/gateway): Add Voyage embedding models

## 1.0.16

### Patch Changes

- Updated dependencies [99964ed]
  - @ai-sdk/provider-utils@3.0.8

## 1.0.15

### Patch Changes

- 980633d: feat(provider/gateway): Add xAI Grok Code Fast 1
- 1c5b88d: feat (provider/gateway): add new model ids

## 1.0.14

### Patch Changes

- Updated dependencies [886e7cd]
  - @ai-sdk/provider-utils@3.0.7

## 1.0.13

### Patch Changes

- c9994f9: feat(provider/gateway): Add cache pricing fields to model metadata
- Updated dependencies [1b5a3d3]
  - @ai-sdk/provider-utils@3.0.6

## 1.0.12

### Patch Changes

- 50e2029: feat (provider/gateway): add deepseek v3.1 thinking model id
- b8478f0: feat (provider/gateway): add mistral medium model id

## 1.0.11

### Patch Changes

- 926259f: feat(provider/gateway): Expose model type in model spec
- c000f96: feat(provider/gateway): Add DeepSeek V3.1

## 1.0.10

### Patch Changes

- Updated dependencies [0857788]
  - @ai-sdk/provider-utils@3.0.5

## 1.0.9

### Patch Changes

- 8b96f99: feat(provider/gateway): Add DeepSeek v3.1 Base

## 1.0.8

### Patch Changes

- Updated dependencies [68751f9]
  - @ai-sdk/provider-utils@3.0.4

## 1.0.7

### Patch Changes

- 28a4006: feat (provider/gateway): add gemini-2.5-flash-lite model id

## 1.0.6

### Patch Changes

- eefa730: refactor(provider/gateway): Make claude-sonnet-4 and similar the primary model slug for Anthropic v4 models
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.3

## 1.0.5

### Patch Changes

- cf7b2ad: feat(provider/gateway): Add GLM-4.5V
- Updated dependencies [38ac190]
  - @ai-sdk/provider-utils@3.0.2

## 1.0.4

### Patch Changes

- 35f93ce: feat (provider/gateway): add new model ids

## 1.0.3

### Patch Changes

- 893aed6: feat (provider/gateway): add anthropic claude 4.1 opus model id

## 1.0.2

### Patch Changes

- 444df49: feat (provider/gateway): update model ids

## 1.0.1

### Patch Changes

- 028fb9c: refactor(provider/gateway): Cleanup old gateway-embedding-options file
- 6331826: feat(provider/gateway): Hide Cohere embedding models with no pricing info
- Updated dependencies [90d212f]
  - @ai-sdk/provider-utils@3.0.1

## 1.0.0

### Patch Changes

- 9e16bfd: feat (provider/gateway): update model ids
- 0477a13: feat (provider/gateway): Add OpenAI embedding support
- 26b6dd0: feat (providers/gateway): include deployment and request id
- 30ab1de: feat (provider/gateway): add grok-4 model id
- e2aceaf: feat: add raw chunk support
- 97fedf9: feat (providers/gateway): include description and pricing info in model list
- c91586a: chore (providers/gateway): update language model ids
- 3cbcbb7: feat (providers/gateway): share common gateway error transform logic
- fedb55e: feat (provider/gateway): add z.ai and glm-4.5 models
- 6c2c708: feat (providers/gateway): initial gateway provider
- 721775e: feat(provider/gateway): Generate new Gateway embedding model settings file
- 70ebead: feat (provider/gateway): add qwen3 coder model id
- f3639fa: feat (providers/gateway): improve oidc api key client auth flow
- 8bd3624: feat (provider/gateway): update model ids to include vercel
- c145d62: feat (providers/gateway): add createGateway shorthand alias for createGatewayProvider
- f77bc38: chore (providers/gateway): update language model ids
- 989ac75: chore (providers/gateway): update chat model ids
- 7742ba3: feat (providers/gateway): add gateway error types with error detail
- c190907: fix (provider/gateway): use zod v4
- d1a034f: feature: using Zod 4 for internal stuff
- d454e4b: fix (providers/gateway): fix timestamp error when streaming objects
- cf1e00e: feat (provider/gateway): add devstral model id
- cc21603: feat (provider/gateway): Add AI Gateway provider options (ordering)
- 205077b: fix: improve Zod compatibility
- e001ea1: fix (provider/gateway): remove unnecessary 'x-' prefix on auth method header
- 27deb4d: feat (provider/gateway): Add providerMetadata to embeddings response
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0
  - @ai-sdk/provider@2.0.0

## 1.0.0-beta.19

### Patch Changes

- 721775e: feat(provider/gateway): Generate new Gateway embedding model settings file
- Updated dependencies [88a8ee5]
  - @ai-sdk/provider-utils@3.0.0-beta.10

## 1.0.0-beta.18

### Patch Changes

- 27deb4d: feat (provider/gateway): Add providerMetadata to embeddings response
- Updated dependencies [27deb4d]
  - @ai-sdk/provider@2.0.0-beta.2
  - @ai-sdk/provider-utils@3.0.0-beta.9

## 1.0.0-beta.17

### Patch Changes

- Updated dependencies [dd5fd43]
  - @ai-sdk/provider-utils@3.0.0-beta.8

## 1.0.0-beta.16

### Patch Changes

- fedb55e: feat (provider/gateway): add z.ai and glm-4.5 models

## 1.0.0-beta.15

### Patch Changes

- Updated dependencies [e7fcc86]
  - @ai-sdk/provider-utils@3.0.0-beta.7

## 1.0.0-beta.14

### Patch Changes

- Updated dependencies [ac34802]
  - @ai-sdk/provider-utils@3.0.0-beta.6

## 1.0.0-beta.13

### Patch Changes

- 0477a13: feat (provider/gateway): Add OpenAI embedding support
- cf1e00e: feat (provider/gateway): add devstral model id
- cc21603: feat (provider/gateway): Add AI Gateway provider options (ordering)

## 1.0.0-beta.12

### Patch Changes

- 70ebead: feat (provider/gateway): add qwen3 coder model id

## 1.0.0-beta.11

### Patch Changes

- 8bd3624: feat (provider/gateway): update model ids to include vercel
- e001ea1: fix (provider/gateway): remove unnecessary 'x-' prefix on auth method header

## 1.0.0-beta.10

### Patch Changes

- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-beta.5

## 1.0.0-beta.9

### Patch Changes

- 205077b: fix: improve Zod compatibility
- Updated dependencies [205077b]
  - @ai-sdk/provider-utils@3.0.0-beta.4

## 1.0.0-beta.8

### Patch Changes

- Updated dependencies [05d2819]
  - @ai-sdk/provider-utils@3.0.0-beta.3

## 1.0.0-beta.7

### Patch Changes

- c190907: fix (provider/gateway): use zod v4

## 1.0.0-beta.6

### Patch Changes

- 9e16bfd: feat (provider/gateway): update model ids

## 1.0.0-beta.5

### Patch Changes

- 30ab1de: feat (provider/gateway): add grok-4 model id

## 1.0.0-beta.4

### Patch Changes

- 97fedf9: feat (providers/gateway): include description and pricing info in model list

## 1.0.0-beta.3

### Patch Changes

- f3639fa: feat (providers/gateway): improve oidc api key client auth flow
- d454e4b: fix (providers/gateway): fix timestamp error when streaming objects

## 1.0.0-beta.2

### Patch Changes

- c91586a: chore (providers/gateway): update language model ids
- d1a034f: feature: using Zod 4 for internal stuff
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-beta.2

## 1.0.0-beta.1

### Patch Changes

- f77bc38: chore (providers/gateway): update language model ids
- Updated dependencies
  - @ai-sdk/provider@2.0.0-beta.1
  - @ai-sdk/provider-utils@3.0.0-beta.1

## 1.0.0-alpha.15

### Patch Changes

- c145d62: feat (providers/gateway): add createGateway shorthand alias for createGatewayProvider
- Updated dependencies
  - @ai-sdk/provider@2.0.0-alpha.15
  - @ai-sdk/provider-utils@3.0.0-alpha.15

## 1.0.0-alpha.14

### Patch Changes

- Updated dependencies
  - @ai-sdk/provider@2.0.0-alpha.14
  - @ai-sdk/provider-utils@3.0.0-alpha.14

## 1.0.0-alpha.13

### Patch Changes

- Updated dependencies [68ecf2f]
  - @ai-sdk/provider@2.0.0-alpha.13
  - @ai-sdk/provider-utils@3.0.0-alpha.13

## 1.0.0-alpha.12

### Patch Changes

- e2aceaf: feat: add raw chunk support
- Updated dependencies [e2aceaf]
  - @ai-sdk/provider@2.0.0-alpha.12
  - @ai-sdk/provider-utils@3.0.0-alpha.12

## 1.0.0-alpha.11

### Patch Changes

- Updated dependencies [c1e6647]
  - @ai-sdk/provider@2.0.0-alpha.11
  - @ai-sdk/provider-utils@3.0.0-alpha.11

## 1.0.0-alpha.10

### Patch Changes

- Updated dependencies [c4df419]
  - @ai-sdk/provider@2.0.0-alpha.10
  - @ai-sdk/provider-utils@3.0.0-alpha.10

## 1.0.0-alpha.9

### Patch Changes

- 26b6dd0: feat (providers/gateway): include deployment and request id
- Updated dependencies [811dff3]
  - @ai-sdk/provider@2.0.0-alpha.9
  - @ai-sdk/provider-utils@3.0.0-alpha.9

## 1.0.0-alpha.8

### Patch Changes

- 3cbcbb7: feat (providers/gateway): share common gateway error transform logic
- 989ac75: chore (providers/gateway): update chat model ids
- 7742ba3: feat (providers/gateway): add gateway error types with error detail
- Updated dependencies
  - @ai-sdk/provider-utils@3.0.0-alpha.8
  - @ai-sdk/provider@2.0.0-alpha.8

## 1.0.0-alpha.7

### Patch Changes

- Updated dependencies [5c56081]
  - @ai-sdk/provider@2.0.0-alpha.7
  - @ai-sdk/provider-utils@3.0.0-alpha.7

## 1.0.0-alpha.6

### Patch Changes

- 6c2c708: feat (providers/gateway): initial gateway provider
- Updated dependencies [0d2c085]
  - @ai-sdk/provider@2.0.0-alpha.6
  - @ai-sdk/provider-utils@3.0.0-alpha.6
