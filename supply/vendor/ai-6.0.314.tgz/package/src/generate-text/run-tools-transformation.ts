import type {
  LanguageModelV3Content,
  LanguageModelV3StreamPart,
  LanguageModelV3ToolChoice,
  SharedV3Warning,
} from '@ai-sdk/provider';
import {
  getErrorMessage,
  type IdGenerator,
  type ModelMessage,
  type SystemModelMessage,
} from '@ai-sdk/provider-utils';
import type { Tracer } from '@opentelemetry/api';
import { ToolCallNotFoundForApprovalError } from '../error/tool-call-not-found-for-approval-error';
import { ToolChoiceViolationError } from '../error/tool-choice-violation-error';
import type { TelemetrySettings } from '../telemetry/telemetry-settings';
import type {
  FinishReason,
  LanguageModelUsage,
  ProviderMetadata,
} from '../types';
import type { Source } from '../types/language-model';
import { asLanguageModelUsage } from '../types/usage';
import { executeToolCall } from './execute-tool-call';
import type {
  StreamTextOnToolCallFinishCallback,
  StreamTextOnToolCallStartCallback,
} from './stream-text';
import {
  DefaultGeneratedFileWithType,
  type GeneratedFile,
} from './generated-file';
import { isApprovalNeeded } from './is-approval-needed';
import { isToolExecutionAllowedFinishReason } from './is-tool-execution-allowed-finish-reason';
import { maybeSignApproval } from './tool-approval-signature';
import { parseToolCall } from './parse-tool-call';
import type { ToolApprovalRequestOutput } from './tool-approval-request-output';
import type { TypedToolCall } from './tool-call';
import type { ToolCallRepairFunction } from './tool-call-repair-function';
import type { TypedToolError } from './tool-error';
import type { TypedToolResult } from './tool-result';
import type { ToolSet } from './tool-set';

export type SingleRequestTextStreamPart<TOOLS extends ToolSet> =
  // Text blocks:
  | {
      type: 'text-start';
      providerMetadata?: ProviderMetadata;
      id: string;
    }
  | {
      type: 'text-delta';
      id: string;
      providerMetadata?: ProviderMetadata;
      delta: string;
    }
  | {
      type: 'text-end';
      providerMetadata?: ProviderMetadata;
      id: string;
    }

  // Reasoning blocks:
  | {
      type: 'reasoning-start';
      providerMetadata?: ProviderMetadata;
      id: string;
    }
  | {
      type: 'reasoning-delta';
      id: string;
      providerMetadata?: ProviderMetadata;
      delta: string;
    }
  | {
      type: 'reasoning-end';
      id: string;
      providerMetadata?: ProviderMetadata;
    }

  // Tool calls:
  | {
      type: 'tool-input-start';
      id: string;
      toolName: string;
      providerMetadata?: ProviderMetadata;
      dynamic?: boolean;
      title?: string;
    }
  | {
      type: 'tool-input-delta';
      id: string;
      delta: string;
      providerMetadata?: ProviderMetadata;
    }
  | {
      type: 'tool-input-end';
      id: string;
      providerMetadata?: ProviderMetadata;
    }
  | ToolApprovalRequestOutput<TOOLS>

  // Other types:
  | ({ type: 'source' } & Source)
  | { type: 'file'; file: GeneratedFile; providerMetadata?: ProviderMetadata } // different because of GeneratedFile object
  | ({ type: 'tool-call' } & TypedToolCall<TOOLS>)
  | ({ type: 'tool-result' } & TypedToolResult<TOOLS>)
  | ({ type: 'tool-error' } & TypedToolError<TOOLS>)
  | { type: 'stream-start'; warnings: SharedV3Warning[] }
  | {
      type: 'response-metadata';
      id?: string;
      timestamp?: Date;
      modelId?: string;
    }
  | {
      type: 'finish';
      finishReason: FinishReason;
      rawFinishReason: string | undefined;
      usage: LanguageModelUsage;
      providerMetadata?: ProviderMetadata;
    }
  | { type: 'error'; error: unknown }
  | { type: 'raw'; rawValue: unknown };

export function runToolsTransformation<TOOLS extends ToolSet>({
  tools,
  toolChoice,
  generatorStream,
  tracer,
  telemetry,
  system,
  messages,
  abortSignal,
  repairToolCall,
  experimental_context,
  toolApprovalSecret,
  generateId,
  stepNumber,
  model,
  onToolCallStart,
  onToolCallFinish,
}: {
  tools: TOOLS | undefined;
  toolChoice?: LanguageModelV3ToolChoice;
  generatorStream: ReadableStream<LanguageModelV3StreamPart>;
  tracer: Tracer;
  telemetry: TelemetrySettings | undefined;
  system: string | SystemModelMessage | Array<SystemModelMessage> | undefined;
  messages: ModelMessage[];
  abortSignal: AbortSignal | undefined;
  repairToolCall: ToolCallRepairFunction<TOOLS> | undefined;
  experimental_context: unknown;
  toolApprovalSecret?: string | Uint8Array;
  generateId: IdGenerator;
  stepNumber?: number;
  model?: { provider: string; modelId: string };
  onToolCallStart?:
    | StreamTextOnToolCallStartCallback<TOOLS>
    | Array<StreamTextOnToolCallStartCallback<TOOLS> | undefined | null>;
  onToolCallFinish?:
    | StreamTextOnToolCallFinishCallback<TOOLS>
    | Array<StreamTextOnToolCallFinishCallback<TOOLS> | undefined | null>;
}): ReadableStream<SingleRequestTextStreamPart<TOOLS>> {
  // tool results stream
  let toolResultsStreamController: ReadableStreamDefaultController<
    SingleRequestTextStreamPart<TOOLS>
  > | null = null;
  let toolResultsStreamClosed = false;
  const toolResultsStream = new ReadableStream<
    SingleRequestTextStreamPart<TOOLS>
  >({
    start(controller) {
      toolResultsStreamController = controller;
    },
    cancel() {
      toolResultsStreamClosed = true;
    },
  });

  function enqueueToolResult(chunk?: SingleRequestTextStreamPart<TOOLS>) {
    if (toolResultsStreamClosed) {
      return;
    }

    try {
      toolResultsStreamController!.enqueue(chunk);
    } catch {
      toolResultsStreamClosed = true;
    }
  }

  function closeToolResultsStream() {
    if (toolResultsStreamClosed) {
      return;
    }

    toolResultsStreamClosed = true;

    try {
      toolResultsStreamController!.close();
    } catch {
      // suppress errors when the stream has been closed
    }
  }

  // keep track of outstanding tool results for stream closing:
  const outstandingToolResults = new Set<string>();
  const toolCallsToExecute: Array<TypedToolCall<TOOLS>> = [];

  // keep track of parsed tool calls so provider-emitted approval requests can reference them
  // keep track of tool inputs for provider-side tool results
  const toolCallsByToolCallId = new Map<string, TypedToolCall<TOOLS>>();

  let canClose = false;
  let finishChunk:
    | (SingleRequestTextStreamPart<TOOLS> & { type: 'finish' })
    | undefined = undefined;

  function attemptClose() {
    // close the tool results controller if no more outstanding tool calls
    if (canClose && outstandingToolResults.size === 0) {
      // we delay sending the finish chunk until all tool results (incl. delayed ones)
      // are received to ensure that the frontend receives tool results before a message
      // finish event arrives.
      if (finishChunk != null) {
        enqueueToolResult(finishChunk);
      }

      closeToolResultsStream();
    }
  }

  function executeToolCallAfterFinish(toolCall: TypedToolCall<TOOLS>) {
    const toolExecutionId = generateId(); // use our own id to guarantee uniqueness
    outstandingToolResults.add(toolExecutionId);

    executeToolCall({
      toolCall,
      tools,
      tracer,
      telemetry,
      messages,
      abortSignal,
      experimental_context,
      stepNumber,
      model,
      onToolCallStart,
      onToolCallFinish,
      onPreliminaryToolResult: result => {
        enqueueToolResult(result);
      },
    })
      .then(result => {
        enqueueToolResult(result);
      })
      .catch(error => {
        enqueueToolResult({
          type: 'error',
          error,
        });
      })
      .finally(() => {
        outstandingToolResults.delete(toolExecutionId);
        attemptClose();
      });
  }

  // Keep input callbacks in the same transform so input availability cannot
  // overtake pending start or delta callbacks in a downstream stream.
  const activeToolCallToolNames = new Map<string, string>();

  // Tool choice none rejects tool calls when the model call finishes.
  // Withhold tool parts so that consumers (e.g. client-side tools) cannot
  // act on them before the rejection, and skip user callbacks that would
  // repair them or process their input.
  const withholdToolParts = toolChoice?.type === 'none';
  const withheldToolContent: Array<LanguageModelV3Content> = [];

  // forward stream
  const forwardStream = new TransformStream<
    LanguageModelV3StreamPart,
    SingleRequestTextStreamPart<TOOLS>
  >({
    async transform(
      chunk: LanguageModelV3StreamPart,
      controller: TransformStreamDefaultController<
        SingleRequestTextStreamPart<TOOLS>
      >,
    ) {
      const chunkType = chunk.type;

      if (
        withholdToolParts &&
        (chunkType === 'tool-input-start' ||
          chunkType === 'tool-input-delta' ||
          chunkType === 'tool-input-end' ||
          chunkType === 'tool-approval-request')
      ) {
        return;
      }

      if (
        withholdToolParts &&
        (chunkType === 'tool-call' || chunkType === 'tool-result')
      ) {
        withheldToolContent.push(chunk);
        return;
      }

      switch (chunkType) {
        // forward:
        case 'stream-start':
        case 'text-start':
        case 'text-delta':
        case 'text-end':
        case 'reasoning-start':
        case 'reasoning-delta':
        case 'reasoning-end':
        case 'source':
        case 'response-metadata':
        case 'error':
        case 'raw': {
          controller.enqueue(chunk);
          break;
        }

        case 'tool-input-start': {
          activeToolCallToolNames.set(chunk.id, chunk.toolName);
          await tools?.[chunk.toolName]?.onInputStart?.({
            toolCallId: chunk.id,
            messages,
            abortSignal,
            experimental_context,
          });
          controller.enqueue(chunk);
          break;
        }

        case 'tool-input-delta': {
          const toolName = activeToolCallToolNames.get(chunk.id);
          if (toolName != null) {
            await tools?.[toolName]?.onInputDelta?.({
              inputTextDelta: chunk.delta,
              toolCallId: chunk.id,
              messages,
              abortSignal,
              experimental_context,
            });
          }
          controller.enqueue(chunk);
          break;
        }

        case 'tool-input-end': {
          activeToolCallToolNames.delete(chunk.id);
          controller.enqueue(chunk);
          break;
        }

        case 'file': {
          controller.enqueue({
            type: 'file',
            file: new DefaultGeneratedFileWithType({
              data: chunk.data,
              mediaType: chunk.mediaType,
            }),
            ...(chunk.providerMetadata != null
              ? { providerMetadata: chunk.providerMetadata }
              : {}),
          });
          break;
        }

        case 'finish': {
          const toolChoiceViolationError =
            withholdToolParts &&
            withheldToolContent.some(part => part.type === 'tool-call')
              ? new ToolChoiceViolationError({
                  toolChoice: { type: 'none' },
                  finishReason: chunk.finishReason.unified,
                  provider: model?.provider ?? 'unknown',
                  modelId: model?.modelId ?? 'unknown',
                  content: withheldToolContent,
                })
              : undefined;

          finishChunk = {
            type: 'finish',
            finishReason:
              toolChoiceViolationError == null
                ? chunk.finishReason.unified
                : 'error',
            rawFinishReason: chunk.finishReason.raw,
            usage: asLanguageModelUsage(chunk.usage),
            providerMetadata: chunk.providerMetadata,
          };

          if (toolChoiceViolationError != null) {
            controller.enqueue({
              type: 'error',
              error: toolChoiceViolationError,
            });
          }

          if (isToolExecutionAllowedFinishReason(chunk.finishReason.unified)) {
            for (const toolCall of toolCallsToExecute.splice(0)) {
              executeToolCallAfterFinish(toolCall);
            }
          } else {
            toolCallsToExecute.length = 0;
          }

          break;
        }

        case 'tool-approval-request': {
          const toolCall = toolCallsByToolCallId.get(chunk.toolCallId);
          if (toolCall == null) {
            enqueueToolResult({
              type: 'error',
              error: new ToolCallNotFoundForApprovalError({
                toolCallId: chunk.toolCallId,
                approvalId: chunk.approvalId,
              }),
            });
            break;
          }

          controller.enqueue({
            type: 'tool-approval-request',
            approvalId: chunk.approvalId,
            toolCall,
          });
          break;
        }

        // process tool call:
        case 'tool-call': {
          try {
            const toolCall = await parseToolCall({
              toolCall: chunk,
              tools,
              repairToolCall,
              system,
              messages,
            });

            toolCallsByToolCallId.set(toolCall.toolCallId, toolCall);
            controller.enqueue({ ...toolCall });

            if (toolCall.invalid) {
              if (!toolCall.providerExecuted) {
                enqueueToolResult({
                  type: 'tool-error',
                  toolCallId: toolCall.toolCallId,
                  toolName: toolCall.toolName,
                  input: toolCall.input,
                  error: getErrorMessage(toolCall.error!),
                  dynamic: true,
                  title: toolCall.title,
                  ...(toolCall.toolMetadata != null
                    ? { toolMetadata: toolCall.toolMetadata }
                    : {}),
                });
              }
              break;
            }

            const tool = tools?.[toolCall.toolName];

            if (tool == null) {
              // ignore tool calls for tools that are not available,
              // e.g. provider-executed dynamic tools
              break;
            }

            if (tool.onInputAvailable != null) {
              await tool.onInputAvailable({
                input: toolCall.input,
                toolCallId: toolCall.toolCallId,
                messages,
                abortSignal,
                experimental_context,
              });
            }

            if (
              await isApprovalNeeded({
                tool,
                toolCall,
                messages,
                experimental_context,
              })
            ) {
              const approvalId = generateId();
              const signature = await maybeSignApproval({
                secret: toolApprovalSecret,
                approvalId,
                toolCallId: toolCall.toolCallId,
                toolName: toolCall.toolName,
                input: toolCall.input,
              });

              enqueueToolResult({
                type: 'tool-approval-request',
                approvalId,
                toolCall,
                ...(signature != null ? { signature } : {}),
              });
              break;
            }

            // Only execute tools that are not provider-executed:
            if (tool.execute != null && toolCall.providerExecuted !== true) {
              toolCallsToExecute.push(toolCall);
            }
          } catch (error) {
            enqueueToolResult({ type: 'error', error });
          }

          break;
        }

        case 'tool-result': {
          const toolName = chunk.toolName as keyof TOOLS & string;
          const toolCall = toolCallsByToolCallId.get(chunk.toolCallId);

          if (chunk.isError) {
            enqueueToolResult({
              type: 'tool-error',
              toolCallId: chunk.toolCallId,
              toolName,
              input: toolCall?.input,
              providerExecuted: true,
              error: chunk.result,
              dynamic: chunk.dynamic,
              ...(chunk.providerMetadata != null
                ? { providerMetadata: chunk.providerMetadata }
                : {}),
              ...(toolCall?.toolMetadata != null
                ? { toolMetadata: toolCall.toolMetadata }
                : {}),
            } as TypedToolError<TOOLS>);
          } else {
            controller.enqueue({
              type: 'tool-result',
              toolCallId: chunk.toolCallId,
              toolName,
              input: toolCall?.input,
              output: chunk.result,
              providerExecuted: true,
              dynamic: chunk.dynamic,
              ...(chunk.providerMetadata != null
                ? { providerMetadata: chunk.providerMetadata }
                : {}),
              ...(toolCall?.toolMetadata != null
                ? { toolMetadata: toolCall.toolMetadata }
                : {}),
            } as TypedToolResult<TOOLS>);
          }
          break;
        }

        default: {
          const _exhaustiveCheck: never = chunkType;
          throw new Error(`Unhandled chunk type: ${_exhaustiveCheck}`);
        }
      }
    },

    flush() {
      canClose = true;
      attemptClose();
    },
  });

  // combine the generator stream and the tool results stream
  return new ReadableStream<SingleRequestTextStreamPart<TOOLS>>({
    async start(controller) {
      // need to wait for both pipes so there are no dangling promises that
      // can cause uncaught promise rejections when the stream is aborted
      return Promise.all([
        generatorStream.pipeThrough(forwardStream).pipeTo(
          new WritableStream({
            write(chunk) {
              controller.enqueue(chunk);
            },
            close() {
              // the generator stream controller is automatically closed when it's consumed
            },
          }),
        ),
        toolResultsStream.pipeTo(
          new WritableStream({
            write(chunk) {
              controller.enqueue(chunk);
            },
            close() {
              controller.close();
            },
          }),
        ),
      ]);
    },
  });
}
